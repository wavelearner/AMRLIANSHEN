#include <iostream>
//#include "mpi.h"
#include "amr.h"
using namespace std;

#define __DOUBLE_PRECISION__

//int amr<T>::nGridTotal=0;

void parse(int argc,char* argv[]);

int main(int argc,char* argv[])
{
	parse(argc,argv);
	cout<<"c++ version: "<<__cplusplus<<endl;
	
	MPI_Init(&argc,&argv);
	#ifdef __DOUBLE_PRECISION__
	amr<double>* cAMR=new amr<double>();
	#else
	amr<float>* cAMR=new amr<float>();
	#endif
	if(!(cAMR->init()))
	{
		cout<<"AMR initialization failed."<<endl;
		return 1;
	}
	else
	{
		while (cAMR->Time < cAMR->Tmax)
		{
			cAMR->nextStep();
			if(cAMR->needReGrid)
			{ 
				cAMR->reGrid();
			}
			if(cAMR->needReBalance)
			{
				cAMR->reBalance();
			}
		}
	}

	MPI_Finalize();
}

void parse(int argc,char* argv[])
{

}
