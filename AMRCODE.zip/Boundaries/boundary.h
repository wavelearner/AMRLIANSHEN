#ifndef __BOUNDARY_H__
#define __BOUNDARY_H__

enum boundaryType {Wall,Symmetry,Periodic,Internal,Inflow,Outflow};


#endif
