#ifndef __flOctTree_H__
#define __flOctTree_H__
#include "flTree.h"

template<class T> class flOctTree:public flTree<T>{

public:
	flOctTree();
	flOctTree(T* Tin);
	bool spawn();
};

template<class T> flOctTree<T>::flOctTree()
{
}

template<class T> flOctTree<T>::flOctTree(T* Tin):
flTree<T>(Tin)
{

}

template<class T> bool flOctTree<T>::spawn(){

	return true;
}

#endif
