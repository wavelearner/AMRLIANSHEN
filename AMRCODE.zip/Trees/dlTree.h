#ifndef __DLTREE_H__
#define __DLTREE_H__
#include "tree.h"

template<class T> class dlTree:public tree<T>{
public:
	dlTree<T> * parent;

	dlTree();
	dlTree(T* Tin);
};

template<class T> dlTree<T>::dlTree()
{
}

template<class T> dlTree<T>::dlTree(T* Tin):
tree<T>(Tin)
{
}
#endif
