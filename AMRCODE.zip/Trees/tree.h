#ifndef __TREE_H__
#define __TREE_H__

template<class T> class tree{
public:
	tree<T>* root;
	tree<T>** children;
	T* nodeData;

public:
	tree();
	tree(T* Tin);
	void insert();
};

template<class T> tree<T>::tree(){

}

template<class T> tree<T>::tree(T* Tin){
	nodeData=Tin;
}

template<class T> void tree<T>::insert(){

}

#endif
