#ifndef __FLTREE_H__
#define __FLTREE_H__
#include "dlTree.h"

template<class T> class flTree:public dlTree<T>{
public:
	flTree<T> *leftSibling;
	flTree<T> *rightSibling;

	flTree();
	flTree(T* Tin);
};

template<class T> flTree<T>::flTree()
{
}

template<class T> flTree<T>::flTree(T* Tin):
dlTree<T>(Tin)
{
}
#endif
