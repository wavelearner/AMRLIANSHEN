#ifndef __AMR_H__
#define __AMR_H__
#include "flOctTree.h"
#include "sCartesianAmrGrid.h"

template <class T> class amr:public flOctTree<sCartesianAmrGrid<T>>{
public:	
	int nMaxLevel;
	static int nGridTotal;
	int nCurrentLevel;
	//flOctTree<sCartesianAmrGrid<T>>* amrTree;

	bool build();
public:
	int cpuID,myID,myGGID,myLGID;
	T Time,Tmax;
	bool needReGrid,needReBalance;

	amr();
	amr(sCartesianAmrGrid<T>*);
	bool init();
	bool nextStep();
	bool reGrid();
	bool reBalance();
	~amr();
};

#endif
