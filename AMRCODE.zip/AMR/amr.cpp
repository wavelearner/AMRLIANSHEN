#include "amr.h"
#include "../Grids/sCartesianAmrGrid.h"
#include "../Trees/flOctTree.h"
#include <fstream>
#include <iostream>
using namespace std;

template<class T> int amr<T>::nGridTotal=0;

template<class T> amr<T>::amr():
nMaxLevel(3)
{
	nGridTotal+=1;	
}

template<class T> amr<T>::amr(sCartesianAmrGrid<T>* Tin):
nMaxLevel(3),flOctTree<sCartesianAmrGrid<T>>(Tin)
{
	nGridTotal+=1;
}

template<class T> bool amr<T>::init()
{
	this->Time=0.0;
	
	ifstream ifsParam("PARAM.IN");
	//ifsParam.open();
	//ifsParam->close();

	ifstream ifsGrid("GRID.IN");
	//ifsGrid.open();
	//ifs->close();
	ifstream ifsPhi("PHI.IN");

	sCartesianAmrGrid<T>* rootGrid=new sCartesianAmrGrid<T>(ifsParam,ifsGrid,ifsPhi);	
	rootGrid->bType[0]=Periodic;
	rootGrid->bType[1]=Periodic;
	rootGrid->bType[2]=Symmetry;
	rootGrid->bType[3]=Symmetry;
	rootGrid->bType[4]=Periodic;
	rootGrid->bType[5]=Periodic;

	this->nodeData=rootGrid;
	this->nCurrentLevel=0;

	this->build();

	//ifsParam.close();
	//ifsGrid.close();
	return false;
}

template<class T> bool amr<T>::nextStep()
{
	return true;
}

template<class T> bool amr<T>::reGrid()
{
	return true;
}

template<class T> bool amr<T>::reBalance()
{
	return true;
}

template<class T> amr<T>::~amr()
{
	nGridTotal-=1;
}

template<class T> bool amr<T>::build()
{	cout<<"in build"<<endl;
	sCartesianAmrGrid<T>* childGrid;

	if(this->nodeData->needRefine() && this->nCurrentLevel<nMaxLevel)
	{
		cout<<"Current level: "<<this->nCurrentLevel<<" We are going to level: "<<this->nCurrentLevel+1<<endl;
		childGrid=this->nodeData->spawn();
		//if(childGrid==NULL){cout<<"Spawn failed!"<<endl;exit(1);}
		cout<<"after spawn"<<endl;
		//amr<T> pamr[8];
		this->children=(tree<sCartesianAmrGrid<T>>**)new amr<T>*[8];	
		for(int i=0;i<8;i++)
		{	
			if(childGrid!=NULL)
			{	//cout<<"before new"<<endl;
				this->children[i]=new amr<T>(childGrid);
				cout<<"Now the total number of grids is "<<amr<T>::nGridTotal<<endl;
				((amr<T>*)this->children[i])->nCurrentLevel=this->nCurrentLevel+1;
				//cout<<"after new"<<endl;
				((amr<T>*)this->children[i])->build();
				//cout<<"before ++"<<endl;
				childGrid++;
			}
		}
		//this->children=pamr;
	}
	else
	{
		return false;
	}	
}

template class amr<float>;
template class amr<double>;
