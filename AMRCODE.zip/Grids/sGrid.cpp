#include "sGrid.h"
#include <iostream>
using namespace std;

template<class T> sGrid<T>::sGrid()
{
}

template<class T> sGrid<T>::sGrid(ifstream& ifsParam)
{
	if(ifsParam.is_open())
	{
		ifsParam>>nx;
		ifsParam>>ny;
		ifsParam>>nz;
		ntotal=nx*ny*nz;
		cout<<"Grid dimension read! nx="<<nx<<" ny="<<ny<<" nz="<<nz<<endl;
	}
	else
	{
		cout<<"Param file error!"<<endl;
		exit(1);
	}
}

template class sGrid<float>;
template class sGrid<double>;
