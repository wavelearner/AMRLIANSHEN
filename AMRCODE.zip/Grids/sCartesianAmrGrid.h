#ifndef __SCARTESIANAMRGRID_H__
#define __SCARTESIANAMRGRID_H__
#include "sCartesianGrid.h"
#include <vector>
#include <fstream>
using namespace std;

template<class T> class sCartesianAmrGrid:public sCartesianGrid<T>{
public:
	T maxD0,maxDx0,maxDy0,maxDz0;
	T *maxD,*maxDx,*maxDy,*maxDz,*phi;

	bool needRefine();
public:
	sCartesianAmrGrid();
	sCartesianAmrGrid(ifstream& ifsParam, ifstream& ifsGrid, ifstream& ifsPhi);

	void dMap();

	sCartesianAmrGrid<T>* spawn();
	 
};

#endif

