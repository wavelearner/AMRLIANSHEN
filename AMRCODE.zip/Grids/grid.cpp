#include "grid.h"

template class grid<float>;
template class grid<double>;

