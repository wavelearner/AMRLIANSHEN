#include "sCartesianAmrGrid.h"
#include <iostream>
#include <fstream>
#include <math.h>
#include "../Boundaries/boundary.h"
using namespace std;

template<class T> sCartesianAmrGrid<T>::sCartesianAmrGrid()
{
}

template<class T> sCartesianAmrGrid<T>::sCartesianAmrGrid(ifstream& ifsParam,ifstream& ifsGrid,ifstream& ifsPhi):
sCartesianGrid<T>(ifsParam,ifsGrid)
{
	phi=new T[this->ntotal];
	if(ifsPhi.is_open())
	{
		for(int i=0;i<this->ntotal;i++)
		{
			ifsPhi>>phi[i];
		}
	}
	else
	{
		cout<<"Phi file is not open!"<<endl;
	}
}

template<class T> void sCartesianAmrGrid<T>::dMap()
{

}

template<class T> bool sCartesianAmrGrid<T>::needRefine()
{
	maxD=new T[this->ntotal];
	int nn;
	for(int k=0;k<this->nz;k++)
	{
		for(int j=0;j<this->ny;j++)
		{
			for(int i=0;i<this->nx;i++)
			{	//cout<<"in needRefine "<<this->nx<<" "<<this->dx[i]<<endl;
				nn=k*this->ny*this->nx+j*this->nx+i; //cout<<"before if"<<endl;
				if(phi[nn]/sqrt(this->dx[i]*this->dx[i]+this->dy[j]*this->dy[j]+this->dz[k]*this->dz[k])<=1.0)
				{
					maxD[nn]=0.005;
					if(this->dx[i]>maxD[nn] || this->dy[j]>maxD[nn] || this->dz[k]>maxD[nn])
					{
						return true;
					}
				}
				else
				{
					maxD[nn]=1.0e10;
				}
			}
		}
	}
	return false;
	//for(int i=0;i<this->ntotal;i++)
	//{
	//	if(phi[i]<0.2 && phi[i]/maxDx[i]<1.0)
	//	{
	//		maxD[i]=0.01;
	//	}
	//}
}

template<class T> void gridInterpolate(const int inx,const int iny,const int inz,sCartesianAmrGrid<T>* gParent,sCartesianAmrGrid<T>* gChild)
{
//the index inx,iny,inz start from 0
	gChild->nx=gParent->nx;
	gChild->ny=gParent->ny;
	gChild->nz=gParent->nz;
	gChild->ntotal=gParent->ntotal;
	gChild->x=new T[gChild->nx+1];
	gChild->y=new T[gChild->ny+1];
	gChild->z=new T[gChild->nz+1];
	gChild->dx=new T[gChild->nx];
	gChild->dy=new T[gChild->ny];
	gChild->dz=new T[gChild->nz];

	gChild->x[0]=gParent->x[inx];
	for(int i=0;i<gChild->nx;i++)
	{
		gChild->dx[i]=(gParent->dx[inx+i/2])/2.0;
		gChild->x[i+1]=gChild->x[i]+gChild->dx[i];
	}
	gChild->y[0]=gParent->y[iny];
	for(int j=0;j<gChild->ny;j++)
	{
		gChild->dy[j]=(gParent->dy[iny+j/2])/2.0;
		gChild->y[j+1]=gChild->y[j]+gChild->dy[j];
	}
	gChild->z[0]=gParent->z[inz];
	for(int k=0;k<gChild->nz;k++)
	{
		gChild->dz[k]=(gParent->dz[inz+k/2])/2.0;
		gChild->z[k+1]=gChild->z[k]+gChild->dz[k];
	}

	gChild->phi=new T[gChild->ntotal];
	//for(int k=0;k<gChild->nz;k++)
	//	for(int j=0;j<gChild->ny;k++)
	//		for(int i=0;i<gChild->nx;i++)
	//		{
	//			gChild->phi[k*(gChild->ny)*(gChild->nx)+j*(gChild->nx)+i]=;
	//		}
	
	if(inx==0)
	{
		gChild->bType[0]=gParent->bType[0];
		gChild->bType[1]=Internal;
	}
	else if(inx==(gParent->nx)/2)
	{
		gChild->bType[0]=Internal;
		gChild->bType[1]=gParent->bType[1];
	}
	else
	{
		gChild->bType[0]=Internal;
		gChild->bType[1]=Internal;
	}

}

template<class T> sCartesianAmrGrid<T>* sCartesianAmrGrid<T>::spawn()
{
// 0 0 0
	sCartesianAmrGrid<T>* childGrid=new sCartesianAmrGrid<T>[8];
	gridInterpolate(0,0,0,this,&childGrid[0]);
	gridInterpolate(this->nx/2,0,0,this,&childGrid[1]);
	gridInterpolate(this->nx/2,this->ny/2,0,this,&childGrid[2]);
	gridInterpolate(0,this->ny/2,0,this,&childGrid[3]);
	gridInterpolate(0,0,this->nz/2,this,&childGrid[4]);
	gridInterpolate(this->nx/2,0,this->nz/2,this,&childGrid[5]);
	gridInterpolate(this->nx/2,this->ny/2,this->nz/2,this,&childGrid[6]);
	gridInterpolate(0,this->ny/2,this->nz/2,this,&childGrid[7]);
	//childGrid->nx=this->nx;
	//childGrid->ny=this->ny;
	//childGrid->nz=this->nz;
	//for(int i=0;i<this->nx;i++)
	//{

	//}
	//for(int j=0;j<this->ny;j++)
	//{
	//}
	//for(int k=0;k<this->nz;k++)
	//{

	//}	
//
	cornerSpawn(childGrid);
	faceXSpawn();
	faceYSpawn();
	faceZSpawn();
	centerSpawn();
	return childGrid;
}

template class sCartesianAmrGrid<float>;
template class sCartesianAmrGrid<double>; 
