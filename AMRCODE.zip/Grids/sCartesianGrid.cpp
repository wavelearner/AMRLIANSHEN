#include "sCartesianGrid.h"
#include <type_traits>
#include <iostream>
using namespace std;

#define __TEST__
template<class T> sCartesianGrid<T>::sCartesianGrid()
{
}

template<class T> sCartesianGrid<T>::sCartesianGrid(ifstream& ifsParam,ifstream& ifsGrid):
sGrid<T>(ifsParam)
{
/*if(!(std::is_same(double,T) || std::is_same(float,T)))
{
	cout<<"Grid template type can only be float or double"<<endl;
	exit(1);
}*/
#ifdef __TEST__
	this->nx=64;
	this->ny=64;
	this->nz=64;
#endif
	if(ifsGrid.is_open())
	{
		x=new T[this->nx+1];
		y=new T[this->ny+1];
		z=new T[this->nz+1];
		dx=new T[this->nx];
		dy=new T[this->ny];
		dz=new T[this->nz];
		ifsGrid>>x[0];
		for(int i=1;i<this->nx+1;i++)
		{
			ifsGrid>>x[i];
			dx[i-1]=x[i]-x[i-1];
		}
		ifsGrid>>y[0];
		for(int j=1;j<this->ny+1;j++)
		{
			ifsGrid>>y[j];
			dy[j-1]=y[j]-y[j-1];
		}
		ifsGrid>>z[0];
		for(int k=1;k<this->nz+1;k++)
		{
			ifsGrid>>z[k];
			dz[k-1]=z[k]-z[k-1];
		}

		cout<<"Initial grid read in!"<<endl;
	}
	else
	{
		cout<<"GRID.IN is not open!"<<endl;
	}
	int ntotal=this->nx*this->ny*this->nz;
	for(int i=0;i<ntotal;i++)
	{
		
	}		
}

template<class T> sCartesianGrid<T>::~sCartesianGrid()
{
	delete x,y,z;
}

template<class T> sCartesianGrid<T>::center2corner(const T* vCenter,T* vCorner)
{
	for(int k=0;k<this->nz;k++)
	{
		for(int j=0;j<this->ny;j++)
		{
			for(int i=0;i<this->nx;i++)
			{

			}	
		}
	}
}

template<class T> sCartesianGrid<T>::corner2center(const T* vCorner,T* vCenter)
{

}

template class sCartesianGrid<float>;
template class sCartesianGrid<double>;
