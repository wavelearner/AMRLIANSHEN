#ifndef __SGRID_H__
#define __SGRID_H__
#include "grid.h"
#include "../Boundaries/boundary.h"
#include <fstream>
using namespace std;

template<class T> class sGrid:public grid<T>{
public:
	int nx,ny,nz,ntotal;
	//enum boundaryType {Wall,Symmetry,Periodic,Internal,Inflow,Outflow};
	boundaryType bType[6];

public:
	sGrid();
	sGrid(ifstream& ifsParam);
};

#endif
