#ifndef __SCARTESIANGRID_H__
#define __SCARTESIANGRID_H__
#include "sGrid.h"
#include <fstream>
//#include <vector>
using namespace std;

template<class T> class sCartesianGrid:public sGrid<T>{
public:
	T *x,*y,*z;
	T *dx,*dy,*dz;
public:
	sCartesianGrid();
	sCartesianGrid(ifstream& ifsParam,ifstream& ifsGrid);
	void center2corner(const T* vCenter,T* vCorner);
	void corner2center(const T* vCorner,T* vCenter);
	~sCartesianGrid();
};

#endif
