#include "interpolate.h"

template<typename T> void center2corner(int nx,int ny,int nz,const T* dx, const T* dy, const T* dz, const T* vCenter,T* vCorner)
{

}

template<typename T> void corner2center(int nx,int ny,int nz,const T* vCorner,T* vCenter)
{

}

template<typename T> void center2cornerG()
{

}

template<typename T> void corner2centerG()
{

}

template center2corner<float>;
template center2corner<double>;
