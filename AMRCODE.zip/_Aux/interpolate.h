#ifndef __INTERPOLATE_H__
#define __INTERPOLATE_H__

template<typename T> inline T trilinear()
{

}

template inline trilinear<float>();
template inline trilinear<double>();

#endif
